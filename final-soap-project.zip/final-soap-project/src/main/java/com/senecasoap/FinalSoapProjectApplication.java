package com.senecasoap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalSoapProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalSoapProjectApplication.class, args);
	}
}
